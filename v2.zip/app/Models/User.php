<?php

namespace App\Models;

use App\Services\SimpleMailService;
use App\Traits\HasPermissions;
use Exception;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Str;
use Laravel\Sanctum\HasApiTokens;
use Tymon\JWTAuth\Contracts\JWTSubject;

class User extends Authenticatable implements JWTSubject, MustVerifyEmail
{
    use HasApiTokens, HasFactory, HasPermissions, Notifiable;

    // Table name (optional, if not following Laravel naming conventions)
    protected $table = 'users';

    // Use UUIDs instead of auto-incrementing IDs
    public $incrementing = false;

    protected $keyType = 'string';

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'userid';

    // Boot method to auto-generate UUIDs
    protected static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            if (empty($model->{$model->getKeyName()})) {
                $model->{$model->getKeyName()} = (string) Str::uuid();
            }
        });
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'userid',
        'name',
        'email',
        'pfno',
        'phonenumber',
        'password',
        'isactive',
        'isadmin',
        'highqualification',
        'officenumber',
        'faxnumber',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'isactive' => 'boolean',
        'isadmin' => 'boolean',
    ];

    public function sendPasswordResetNotification($token)
    {
        $frontendUrl = config('app.frontend_url', config('app.url'));
        $url = $frontendUrl.'/auth/reset-password?token='.$token.'&email='.urlencode($this->email);
        $content = 'You are receiving this email because we received a password reset request for your account. This link will expire in 60 minutes.';

        SimpleMailService::send($this->email, 'Reset Your Password', $content, $url, 'Reset Password');
    }

    public function sendEmailVerificationNotification()
    {
        $frontendUrl = config('app.frontend_url', config('app.url'));
        $url = $frontendUrl.'/verify-email?id='.$this->userid.'&hash='.sha1($this->email);
        $content = 'Please click the button below to verify your email address.';

        SimpleMailService::send($this->email, 'Verify Your Email Address', $content, $url, 'Verify Email');
    }

    // functions
    public function permissions()
    {
        return $this->belongsToMany(Permission::class, 'userpermissions', 'useridfk', 'permissionidfk');
    }

    public function notifiabletypes()
    {
        return $this->belongsToMany(NotificationType::class, 'notifiableusers', 'useridfk', 'notificationfk');

    }

    public function department()
    {
        return $this->hasOneThrough(
            Department::class,
            Proposal::class,
            'useridfk', // Foreign key on proposals table
            'depid', // Foreign key on departments table
            'userid', // Local key on users table
            'departmentidfk' // Local key on proposals table
        )->latest();
    }

    public function haspermission($shortname)
    {

        // Check user permissions
        return $this->permissions()->where('shortname', $shortname)->exists();
    }

  

    public function canapproveproposal($proposalid)
    {
        try {
            $proposal = Proposal::findOrFail($proposalid);
            if ($this->haspermission('canapproveproposal') && ($proposal->useridfk != $this->userid) && $proposal->receivedstatus == \App\Models\ReceivedStatus::RECEIVED && $proposal->approvalstatus == \App\Models\ApprovalStatus::PENDING) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $exception) {
            return false;
        }

    }

    public function canrejectproposal($proposalid)
    {
        try {
            $proposal = Proposal::findOrFail($proposalid);
            if ($this->haspermission('canrejectproposal') && ($proposal->useridfk != $this->userid) && $proposal->receivedstatus == \App\Models\ReceivedStatus::RECEIVED && $proposal->approvalstatus == \App\Models\ApprovalStatus::PENDING) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $exception) {
            return false;
        }

    }

    public function canproposechanges($proposalid)
    {
        try {
            $proposal = Proposal::findOrFail($proposalid);
            if ($this->haspermission('canproposechanges') && ($proposal->useridfk != $this->userid) && $proposal->approvalstatus == \App\Models\ApprovalStatus::PENDING && $proposal->receivedstatus == \App\Models\ReceivedStatus::RECEIVED) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $exception) {
            return false;
        }

    }

    public function canreceiveproposal($proposalid)
    {
        try {
            $proposal = Proposal::findOrFail($proposalid);
            if ($this->haspermission('canreceiveproposal') && ($proposal->useridfk != $this->userid) && $proposal->approvalstatus == \App\Models\ApprovalStatus::PENDING && $proposal->submittedstatus == \App\Models\SubmittedStatus::SUBMITTED && $proposal->receivedstatus == \App\Models\ReceivedStatus::PENDING) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $exception) {
            return false;
        }

    }

    public function canenableediting($proposalid)
    {
        try {
            $proposal = Proposal::findOrFail($proposalid);
            if ($this->haspermission('canenabledisableproposaledit') && ($proposal->useridfk != $this->userid) && $proposal->approvalstatus == \App\Models\ApprovalStatus::PENDING && $proposal->submittedstatus == \App\Models\SubmittedStatus::SUBMITTED && $proposal->receivedstatus == \App\Models\ReceivedStatus::RECEIVED && ! $proposal->allowediting) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $exception) {
            return false;
        }

    }

    public function candisableediting($proposalid)
    {
        try {
            $proposal = Proposal::findOrFail($proposalid);
            if ($this->haspermission('canenabledisableproposaledit') && ($proposal->useridfk != $this->userid) && $proposal->approvalstatus == \App\Models\ApprovalStatus::PENDING && $proposal->submittedstatus == \App\Models\SubmittedStatus::SUBMITTED && $proposal->receivedstatus == \App\Models\ReceivedStatus::RECEIVED && $proposal->allowediting) {
                return true;
            } else {
                return false;
            }
        } catch (Exception $exception) {
            return false;
        }

    }

    public function proposals()
    {
        return $this->hasMany(Proposal::class, 'useridfk', 'userid');
    }

    // public function getEffectivePermissions()
    // {
       
    //     // Only user-assigned permissions
    //     return $this->permissions()->pluck('shortname')->toArray();
    // }

    public function hasPermissionDynamic($permission)
    {
        
        return $this->permissions()->where('shortname', $permission)->exists();
    }

    public function notifications()
    {
        return $this->hasMany(Notification::class, 'user_id', 'userid');
    }

    public function unreadNotifications()
    {
        return $this->notifications()->unread();
    }

    // JWT Methods
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    public function getJWTCustomClaims()
    {
        return [];
    }
}
