<?php

namespace App\Http\Controllers;

use App\Models\FinancialYear;
use App\Models\GlobalSetting;
use App\Models\Grant;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class GrantsController extends Controller
{
    //
    public function postnewgrant(Request $request)
    {
        if (!auth()->user()->isadmin) {
            return response()->json(['success' => false, 'message' => 'You are not Authorized to Add or Edit a Grant!'], 403);
        }
        // Validate incoming request data if needed
        // Define validation rules
        $rules = [
            'title' => 'required|string', // Example rules, adjust as needed
            'finyearfk' => 'required|string', // Adjust data types as per your schema
            'status' => 'required|string',
        ];




        // Validate incoming request
        $validator = Validator::make($request->all(), $rules);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json(['success' => false, 'message' => 'Fill all the required Fields!'], 400);
        }

        // Assuming you're retrieving grantno, departmentid, and userid from the request
        $grant = new Grant(); // Ensure the model name matches your actual model class name
        // Assign values from the request
        $grant->title = $request->input('title');
        $grant->finyearfk = $request->input('finyearfk');
        $grant->status = $request->input('status');
        $grant->save();

        return response()->json(['success' => true, 'message' => 'Grant Saved Successfully!!', 'data' => $grant], 201);


    }

    public function updategrant(Request $request, $id)
    {
        if (!auth()->user()->isadmin) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403); // message: "You are not Authorized to Add or Edit a Grant!";
        }
        // Validate incoming request data if needed
        // Define validation rules
        $rules = [
            'title' => 'required|string', // Example rules, adjust as needed
            'finyear' => 'required|string', // Adjust data types as per your schema
            'status' => 'required|string',
        ];



        // Validate incoming request
        $validator = Validator::make($request->all(), $rules);

        // Check if validation fails
        if ($validator->fails()) {
            // return response()->json(['error' => $validator->errors()], 400);
            return response(['message' => 'Fill all the required Fields!', 'type' => 'danger'], 400);

        }

        // Assuming you're retrieving grantno, departmentid, and userid from the request
        $grant = Grant::findOrFail($id); // Ensure the model name matches your actual model class name
        // Assign values from the request
        $grant->title = $request->input('title');
        $grant->finyearfk = $request->input('finyear');
        $grant->status = $request->input('status');
        $grant->save();

        // Optionally, return a response or redirect
        // return response()->json(['message' => 'Proposal created successfully'], 201);
        return response(['message' => 'Grant Updated Successfully!!', 'type' => 'success']);


    }
    public function viewallgrants()
    {
        $allgrants = Grant::with('financialyear')->get();
        $finyears = FinancialYear::all();
        $currentsettings =[
            'current_grant'=>GlobalSetting::where('item','current_open_grant')->first()->value1 ?? null,
            'current_year'=>GlobalSetting::where('item','current_fin_year')->first()->value1 ?? null
        ];
        return response()->json([
            'success' => true,
            'data' => [
                'grants' => $allgrants,
                'financial_years' => $finyears,
                'current_settings' => $currentsettings
            ]
        ]);
    }
    
    public function getviewsinglegrantpage($id)
    {
        if (!auth()->user()->isadmin) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }
        
        $grant = Grant::findOrFail($id);
        
        return response()->json([
            'success' => true,
            'data' => [
                'grant' => $grant,
                'isreadonlypage' => true,
                'isadminmode' => true
            ]
        ]);
    }
    
    public function geteditsinglegrantpage($id)
    {
        if (!auth()->user()->isadmin) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }
        
        $grant = Grant::findOrFail($id);
        
        return response()->json([
            'success' => true,
            'data' => [
                'grant' => $grant,
                'isreadonlypage' => true,
                'isadminmode' => true
            ]
        ]);
    }

    public function fetchallgrants()
    {
        try {
            $data = Grant::with('financialyear')->get();
            return response()->json(['success' => true, 'data' => $data]);
        } catch (Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage(), 'data' => []], 500);
        }
    }

    public function fetchsearchgrants(Request $request)
    {
        $searchTerm = $request->input('search');
        $data = Grant::all()->where('finyear', 'like', '%' . $searchTerm . '%')
            ->orWhere('grantid', 'like', '%' . $searchTerm . '%')
            ->orWhere('status', 'like', '%' . $searchTerm . '%')
            ->get();
        return response()->json($data); // Return filtered data as JSON
    }


    //settings
    public function postcurrentgrant(Request $request)
    {
        if (!auth()->user()->isadmin) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403); // message: "You are not Authorized to Update Current Settings!";
        }
        // Validate incoming request data if needed
        // Define validation rules
        $rules = [ 
            'current_grantno' => 'required|string',
        ];



        // Validate incoming request
        $validator = Validator::make($request->all(), $rules);

        // Check if validation fails
        if ($validator->fails()) {
            // return response()->json(['error' => $validator->errors()], 400);
            return response(['message' => 'Fill all the required Fields!', 'type' => 'danger'], 400);

        }

        $item = GlobalSetting::where('item','current_open_grant')->firstOrFail(); 
        $item->value1 = $request->input('current_grantno'); 
        $item->save();

        // Optionally, return a response or redirect
        // return response()->json(['message' => 'Proposal created successfully'], 201);
        return response(['message' => 'Current Grant Updated Successfully!!', 'type' => 'success']);


    }

    public function postcurrentfinyear(Request $request)
    {
        if (!auth()->user()->isadmin) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403); // message: "You are not Authorized to Update Current Settings!";
        }
        // Validate incoming request data if needed
        // Define validation rules
        $rules = [ 
            'current_fin_year' => 'required|string',
        ];



        // Validate incoming request
        $validator = Validator::make($request->all(), $rules);

        // Check if validation fails
        if ($validator->fails()) {
            // return response()->json(['error' => $validator->errors()], 400);
            return response(['message' => 'Fill all the required Fields!', 'type' => 'danger'], 400);

        }

        $item = GlobalSetting::where('item','current_fin_year')->firstOrFail(); 
        $item->value1 = $request->input('current_fin_year'); 
        $item->save();

        // Optionally, return a response or redirect
        // return response()->json(['message' => 'Proposal created successfully'], 201);
        return response(['message' => 'Current Financial Year Updated Successfully!!', 'type' => 'success']);


    }
}
