<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Department Details</h3>
                    <div class="card-tools">
                        <a href="<?php echo e(route('pages.departments.editdepartment', $department->depid)); ?>" class="btn btn-primary btn-sm">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <strong>Department Name:</strong>
                            <p><?php echo e($department->shortname); ?></p>
                        </div>
                        <div class="col-md-6">
                            <strong>School:</strong>
                            <p><?php echo e($department->school->shortname ?? 'N/A'); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <strong>Description:</strong>
                            <p><?php echo e($department->description); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/felix/projects/Kabianga-arg/resources/views/pages/departments/show.blade.php ENDPATH**/ ?>