<?php $__env->startSection('title', 'User Permissions - UoK ARG Portal'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid fade-in">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">User Permissions & Roles</h2>
            <p class="text-muted mb-0">Manage user <?php echo e($user->name); ?> permissions and role assignments</p>
        </div>
        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-2"></i>Back to Users
        </a>
    </div>

    <div class="row">
        <!-- User Info Card -->
        <div class="col-md-4">
            <div class="form-card">
                <h5 class="mb-3">User Information</h5>
                <div class="mb-3">
                    <strong>Name:</strong> <?php echo e($user->name); ?>

                </div>
                <div class="mb-3">
                    <strong>Email:</strong> <?php echo e($user->email); ?>

                </div>
                <div class="mb-3">
                    <strong>Status:</strong>
                    <span class="badge <?php echo e($user->isactive ? 'bg-success' : 'bg-danger'); ?>">
                        <?php echo e($user->isactive ? 'Active' : 'Inactive'); ?>

                    </span>
                </div>
                <div class="mb-3">
                    <strong>Super Admin:</strong>
                    <span class="badge <?php echo e($user->isadmin ? 'bg-warning' : 'bg-secondary'); ?>">
                        <?php echo e($user->isadmin ? 'Yes' : 'No'); ?>

                    </span>
                </div>
            </div>
        </div>

        <!-- Status Management -->
        <div class="col-md-8">
            <div class="form-card mb-4">
                <h5 class="mb-3">Account Status</h5>
                <form id="statusForm" action="/api/v1/users/<?php echo e($user->userid); ?>/status" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Account Status</label>
                            <select class="form-select" name="isactive">
                                <option value="1" <?php echo e($user->isactive ? 'selected' : ''); ?>>Active</option>
                                <option value="0" <?php echo e(!$user->isactive ? 'selected' : ''); ?>>Inactive</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Update Status</button>
                </form>
            </div>

            <?php if(auth()->user()->issuperadmin()): ?>
            <!-- Super Admin Management -->
            <div class="form-card mb-4">
                <h5 class="mb-3">Super Administrator Role</h5>
                <div class="alert alert-warning">
                    <i class="bi bi-exclamation-triangle me-2"></i>
                    <strong>Warning:</strong> Super administrators bypass all permission checks and have full system access.
                </div>
                <form id="superAdminForm" action="/api/v1/users/<?php echo e($user->userid); ?>/superadmin" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" name="isadmin" value="1" 
                               <?php echo e($user->isadmin ? 'checked' : ''); ?> id="isAdminCheck">
                        <label class="form-check-label" for="isAdminCheck">
                            Grant Super Administrator privileges
                        </label>
                    </div>
                    <button type="submit" class="btn btn-warning">Update Super Admin Status</button>
                </form>
            </div>
            <?php endif; ?>

            <!-- Permissions Management -->
            <div class="form-card">
                <h5 class="mb-3">User Permissions</h5>
                <form id="permissionsForm" action="/api/v1/users/<?php echo e($user->userid); ?>/permissions" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="row">
                        <?php $__currentLoopData = $availablePermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 mb-2">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" 
                                           name="permissions[]" value="<?php echo e($permission->pid); ?>"
                                           <?php echo e($userPermissions->contains('pid', $permission->pid) ? 'checked' : ''); ?>

                                           id="perm_<?php echo e($permission->pid); ?>">
                                    <label class="form-check-label" for="perm_<?php echo e($permission->pid); ?>">
                                        <?php echo e($permission->menuname); ?>

                                        <small class="text-muted d-block"><?php echo e($permission->shortname); ?></small>
                                    </label>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-3">
                        <button type="submit" class="btn btn-success">Update Permissions</button>
                        <button type="button" class="btn btn-outline-secondary" onclick="clearAllPermissions()">Clear All</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Status form submission
    document.getElementById('statusForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const data = Object.fromEntries(formData);
        
        fetch(this.action, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showAlert('Status updated successfully', 'success');
            } else {
                showAlert(data.message || 'Failed to update status', 'error');
            }
        })
        .catch(error => {
            showAlert('An error occurred', 'error');
        });
    });

    // Super Admin form submission
    const superAdminForm = document.getElementById('superAdminForm');
    if (superAdminForm) {
        superAdminForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            if (!confirm('Are you sure you want to change super administrator status? This will grant/revoke full system access.')) {
                return;
            }
            
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            
            fetch(this.action, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAlert('Super admin status updated successfully', 'success');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showAlert(data.message || 'Failed to update super admin status', 'error');
                }
            })
            .catch(error => {
                showAlert('An error occurred', 'error');
            });
        });
    }

    // Permissions form submission
    document.getElementById('permissionsForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get selected permissions
        const selectedPermissions = [];
        document.querySelectorAll('input[name="permissions[]"]:checked').forEach(checkbox => {
            selectedPermissions.push(checkbox.value);
        });
        
        console.log('Selected permissions:', selectedPermissions);
        
        const formData = new FormData();
        formData.append('_token', document.querySelector('meta[name="csrf-token"]').content);
        formData.append('_method', 'PATCH');
        
        selectedPermissions.forEach(permission => {
            formData.append('permissions[]', permission);
        });
        
        fetch(this.action, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            },
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            console.log('Response:', data);
            if (data.success) {
                showAlert('Permissions updated successfully', 'success');
            } else {
                showAlert(data.message || 'Failed to update permissions', 'error');
            }
        })
        .catch(error => {
            console.log('Error:', error);
            showAlert('An error occurred', 'error');
        });
    });
});

function showAlert(message, type) {
    const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
    const alertHtml = `<div class="alert ${alertClass} alert-dismissible fade show" role="alert">
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>`;
    
    const container = document.querySelector('.container-fluid');
    container.insertAdjacentHTML('afterbegin', alertHtml);
    
    setTimeout(() => {
        const alert = container.querySelector('.alert');
        if (alert) alert.remove();
    }, 5000);
}

function clearAllPermissions() {
    document.querySelectorAll('input[name="permissions[]"]').forEach(checkbox => {
        checkbox.checked = false;
    });
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/felix/projects/Kabianga-arg/resources/views/pages/users/permissions.blade.php ENDPATH**/ ?>