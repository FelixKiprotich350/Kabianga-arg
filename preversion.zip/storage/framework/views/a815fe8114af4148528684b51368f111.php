<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Research Proposal - <?php echo e($proposal->proposalcode); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Times New Roman', serif;
            font-size: 11px;
            line-height: 1.4;
            color: #2c3e50;
            background: #fff;
            margin: 0;
            padding: 5px;
        }

        .page-container {
            max-width: 100%;
            margin: 0;
            padding: 0;
        }

        .header {
            text-align: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 3px solid #88CDFF;
        }

        .university-logo {
            width: 70px;
            height: auto;
            margin-bottom: 8px;
        }

        .university-name {
            font-size: 18px;
            font-weight: bold;
            color: #88CDFF;
            margin-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .document-title {
            font-size: 14px;
            font-weight: bold;
            color: #34495e;
            margin: 8px 0;
            text-transform: uppercase;
        }

        .proposal-meta {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
            font-size: 10px;
            color: #7f8c8d;
        }

        .content {
            margin-top: 20px;
        }

        .section {
            margin-bottom: 25px;
            page-break-inside: avoid;
        }

        .section-title {
            font-size: 13px;
            font-weight: bold;
            color: #6c757d;
            margin-bottom: 10px;
            padding: 6px 10px;
            background: #f8f9fa;
            border-left: 3px solid #88CDFF;
            text-transform: uppercase;
        }

        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
            margin-left: 0;
        }

        .info-table th {
            background: #88CDFF;
            color: #495057;
            font-weight: bold;
            padding: 8px 10px;
            text-align: left;
            font-size: 11px;
            width: 150px;
        }

        .info-table td {
            padding: 10px 12px;
            border: 1px solid #dee2e6;
            background: #fff;
            vertical-align: top;
            text-align: left;
        }

        .info-table tr:nth-child(even) td {
            background: #f8f9fa;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }

        .data-table th {
            background: #88CDFF;
            color: #495057;
            font-weight: bold;
            padding: 6px 8px;
            text-align: left;
            font-size: 10px;
            border: 1px solid #88CDFF;
        }

        .data-table td {
            padding: 8px 10px;
            border: 1px solid #dee2e6;
            background: #fff;
            font-size: 10px;
            vertical-align: top;
        }

        .data-table tr:nth-child(even) td {
            background: #f8f9fa;
        }

        .text-content {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            border-left: 4px solid #88CDFF;
            margin-bottom: 15px;
            text-align: justify;
            line-height: 1.5;
        }

        .footer {
            margin-top: 30px;
            padding-top: 15px;
            border-top: 2px solid #88CDFF;
            text-align: center;
            font-size: 10px;
            color: #7f8c8d;
        }

        .footer .disclaimer {
            font-style: italic;
            margin-bottom: 5px;
        }

        .footer .copyright {
            font-weight: bold;
            color: #88CDFF;
        }

        .amount {
            font-weight: bold;
            color: #27ae60;
        }

        .status {
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 9px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .status.pending {
            background: #fff3cd;
            color: #856404;
        }

        .status.approved {
            background: #d4edda;
            color: #155724;
        }

        .status.rejected {
            background: #f8d7da;
            color: #721c24;
        }

        @media print {
            body {
                padding: 10px;
            }

            .page-container {
                margin: 0;
            }
        }
    </style>

</head>

<body>
    <div class="page-container">
        <div class="header">
            <img src="data:image/png;base64,<?php echo e(base64_encode(file_get_contents(public_path('images/logo.png')))); ?>"
                alt="University Logo" class="university-logo" />
            <div class="university-name">University of Kabianga</div>
            <div class="document-title">Annual Research Grant Proposal</div>
            <div class="proposal-meta">
                <span><strong>Proposal Code:</strong> <?php echo e($proposal->proposalcode); ?></span>
                <span><strong>Generated:</strong> <?php echo e(\Carbon\Carbon::now()->format('F j, Y \a\t g:i A')); ?></span>
                <span class="status <?php echo e($proposal->approvalstatus); ?>"><?php echo e($proposal->approvalstatus); ?></span>
            </div>
        </div>
        <div class="content">
            <div class="section">
                <div class="section-title">A: Principal Investigator Details</div>
                <table class="info-table">
                    <tr>
                        <th>Full Name</th>
                        <td><?php echo e($proposal->applicant->name); ?></td>
                    </tr>
                    <tr>
                        <th>Email Address</th>
                        <td><?php echo e($proposal->applicant->email); ?></td>
                    </tr>
                    <tr>
                        <th>Phone Number</th>
                        <td><?php echo e($proposal->applicant->phonenumber ?? 'Not provided'); ?></td>
                    </tr>
                    <tr>
                        <th>Gender</th>
                        <td><?php echo e($proposal->applicant->gender ?? 'Not specified'); ?></td>
                    </tr>
                    <tr>
                        <th>Department</th>
                        <td><?php echo e($proposal->department->description ?? ($proposal->department->shortname ?? 'Not specified')); ?>

                        </td>
                    </tr>
                </table>
            </div>

            <div class="section">
                <div class="section-title">B: Research Project Overview</div>
                <table class="info-table">
                    <tr>
                        <th>Research Title</th>
                        <td><strong><?php echo e($proposal->researchtitle); ?></strong></td>
                    </tr>
                    <tr>
                        <th>Research Theme</th>
                        <td><?php echo e($proposal->themeitem->themename ?? 'Not specified'); ?></td>
                    </tr>
                    <tr>
                        <th>Grant Type</th>
                        <td><?php echo e($proposal->grantitem->title ?? 'Not specified'); ?></td>
                    </tr>
                    <tr>
                        <th>Requested Amount</th>
                        <td class="amount"><?php echo e($proposal->grantitem->status ?? 'Not specified'); ?></td>
                    </tr>
                    <tr>
                        <th>Project Duration</th>
                        <td><?php echo e(\Carbon\Carbon::parse($proposal->commencingdate)->format('M j, Y')); ?> -
                            <?php echo e(\Carbon\Carbon::parse($proposal->terminationdate)->format('M j, Y')); ?></td>
                    </tr>
                </table>
            </div>

            <div class="section">
                <div class="section-title">C: Research Objectives</div>
                <div class="text-content">
                    <?php echo e($proposal->objectives ?? 'Not provided'); ?>

                </div>
            </div>

            <div class="section">
                <div class="section-title">D: Research Hypothesis</div>
                <div class="text-content">
                    <?php echo e($proposal->hypothesis ?? 'Not provided'); ?>

                </div>
            </div>

            <div class="section">
                <div class="section-title">E: Research Significance</div>
                <div class="text-content">
                    <?php echo e($proposal->significance ?? 'Not provided'); ?>

                </div>
            </div>

            <div class="section">
                <div class="section-title">F: Ethical Considerations</div>
                <div class="text-content">
                    <?php echo e($proposal->ethicals ?? 'Not provided'); ?>

                </div>
            </div>

            <div class="section">
                <div class="section-title">G: Expected Outputs</div>
                <div class="text-content">
                    <?php echo e($proposal->expoutput ?? 'Not provided'); ?>

                </div>
            </div>

            <div class="section">
                <div class="section-title">H: Social Impact</div>
                <div class="text-content">
                    <?php echo e($proposal->socio_impact ?? 'Not provided'); ?>

                </div>
            </div>

            <div class="section">
                <div class="section-title">I: Expected Research Findings</div>
                <div class="text-content">
                    <?php echo e($proposal->res_findings ?? 'Not provided'); ?>

                </div>
            </div>

            <div class="section">
                <div class="section-title">J: Budget & Expenditures</div>
                <?php if($proposal->expenditures && $proposal->expenditures->count() > 0): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40%;">Item Description</th>
                                <th style="width: 25%;">Category</th>
                                <th style="width: 20%;">Unit Cost</th>
                                <th style="width: 15%;">Total Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $totalBudget = 0; ?>
                            <?php $__currentLoopData = $proposal->expenditures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expenditure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $totalBudget += $expenditure->total ?? 0; ?>
                                <tr>
                                    <td><?php echo e($expenditure->item ?? 'Not specified'); ?></td>
                                    <td><?php echo e($expenditure->itemtype ?? 'General'); ?></td>
                                    <td class="amount">KES <?php echo e(number_format($expenditure->unitprice ?? 0, 2)); ?></td>
                                    <td class="amount">KES <?php echo e(number_format($expenditure->total ?? 0, 2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr style="background: #e9ecef; font-weight: bold;">
                                <td colspan="3" style="text-align: right;">Total Budget:</td>
                                <td class="amount">KES <?php echo e(number_format($totalBudget, 2)); ?></td>
                            </tr>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="text-content">No expenditure details provided.</div>
                <?php endif; ?>
            </div>

            <div class="section">
                <div class="section-title">K: Research Methodology & Design</div>
                <?php if($proposal->researchdesigns && $proposal->researchdesigns->count() > 0): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 40%;">Methodology Summary</th>
                                <th style="width: 30%;">Key Indicators</th>
                                <th style="width: 30%;">Expected Goals</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $proposal->researchdesigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $design): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($design->summary ?? 'Not provided'); ?></td>
                                    <td><?php echo e($design->indicators ?? 'Not provided'); ?></td>
                                    <td><?php echo e($design->goal ?? 'Not provided'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="text-content">No research design details provided.</div>
                <?php endif; ?>
            </div>

            <div class="section">
                <div class="section-title">L: Project Work Plan</div>
                <?php if($proposal->workplans && $proposal->workplans->count() > 0): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 35%;">Activity</th>
                                <th style="width: 20%;">Timeline</th>
                                <th style="width: 25%;">Required Input</th>
                                <th style="width: 20%;">Responsible Person</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $proposal->workplans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workplan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($workplan->activity ?? 'Not specified'); ?></td>
                                    <td><?php echo e($workplan->time ?? 'Not specified'); ?></td>
                                    <td><?php echo e($workplan->input ?? 'Not specified'); ?></td>
                                    <td><?php echo e($workplan->bywhom ?? 'Not specified'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="text-content">No work plan details provided.</div>
                <?php endif; ?>
            </div>


            <div class="section">
                <div class="section-title">M: Research Collaborators</div>
                <?php if($proposal->collaborators && $proposal->collaborators->count() > 0): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 35%;">Collaborator Name</th>
                                <th style="width: 25%;">Role/Position</th>
                                <th style="width: 40%;">Institution/Organization</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $proposal->collaborators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collaborator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($collaborator->collaboratorname ?? 'Not provided'); ?></td>
                                    <td><?php echo e($collaborator->position ?? 'Not specified'); ?></td>
                                    <td><?php echo e($collaborator->institution ?? 'Not specified'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="text-content">No collaborators listed for this research project.</div>
                <?php endif; ?>
            </div>

            <div class="section">
                <div class="section-title">N: Related Publications</div>
                <?php if($proposal->publications && $proposal->publications->count() > 0): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 50%;">Publication Title</th>
                                <th style="width: 35%;">Publisher/Journal</th>
                                <th style="width: 15%;">Year</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $proposal->publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($publication->title ?? 'Not provided'); ?></td>
                                    <td><?php echo e($publication->publisher ?? 'Not specified'); ?></td>
                                    <td><?php echo e($publication->year ?? 'N/A'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="text-content">No related publications listed.</div>
                <?php endif; ?>
            </div>

            <?php if($proposal->comment): ?>
                <div class="section">
                    <div class="section-title">O: Additional Comments & Notes</div>
                    <div class="text-content">
                        <?php echo e($proposal->comment); ?>

                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div class="footer">
            <div class="disclaimer">
                <strong>Disclaimer:</strong> This is a computer-generated document and does not require a physical
                signature.
            </div>
            <div class="copyright">
                &copy; <?php echo e(\Carbon\Carbon::now()->format('Y')); ?> University of Kabianga - Annual Research Grants Program
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH /home/felix/projects/Kabianga-arg/resources/views/pages/proposals/printproposal.blade.php ENDPATH**/ ?>