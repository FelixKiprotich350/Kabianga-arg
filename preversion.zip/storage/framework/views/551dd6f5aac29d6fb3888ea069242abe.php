<footer class="modern-footer">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-md-6">
                <small>&copy; <?php echo e(date('Y')); ?> University of Kabianga. All rights reserved.</small>
            </div>
            <div class="col-md-6 text-end">
                <small>ARG Portal v1.0 | Powered by <a href="https://biupsols.com" target="_blank" style="color: #60a5fa; text-decoration: none;">biupsols.com</a></small>
            </div>
        </div>
    </div>
</footer><?php /**PATH /home/felix/projects/Kabianga-arg/resources/views/partials/modern-footer.blade.php ENDPATH**/ ?>