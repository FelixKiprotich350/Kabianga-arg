
    $(document).ready(function() {
        $('#menuToggle').click(function() {
            ARGPortal.showInfo('Menu toggle clicked!');
        });
    });