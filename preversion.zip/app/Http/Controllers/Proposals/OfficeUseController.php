<?php

namespace App\Http\Controllers\Proposals;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class OfficeUseController extends Controller
{
    //
}
